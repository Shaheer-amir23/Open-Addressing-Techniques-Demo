package LinearProbing;

public class ValueEntry {//start of class

    private Integer key; //private variable

    public ValueEntry() { //constructor without argument
        this.key = -1;
    }

    public ValueEntry(Integer key) {//constructor with argument
        setKey(key);//call setKey method
    }

    public Integer getKey() {//getter method
        return key;
    }

    public void setKey(Integer key) {//setter method
        this.key = key;//set global key equal to passed through key
    }
}//end of clas
