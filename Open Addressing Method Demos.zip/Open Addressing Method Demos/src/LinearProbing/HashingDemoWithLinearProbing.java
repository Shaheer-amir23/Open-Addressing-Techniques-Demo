package LinearProbing;

import java.util.Scanner;

public class HashingDemoWithLinearProbing { //start of main class
    //creating global variables
    public static int items;
    public static double lf;
    public static int tableCapacity;
    //creating global hashtables
    public static ValueEntry[] hashTable;
    public static ValueEntry[] workingHashTable;
    //creating a global scanner
    public static Scanner input = new Scanner(System.in);

    //start of reHashingWithLinearProbe method
    public static void reHashingWithLinearProbe() {

        int newCapacity = checkPrime(tableCapacity*2); //creating the new capacity and ensuring it is a prime number
        workingHashTable = new ValueEntry[newCapacity]; //create the working hash table with the new capacity

        for (int i = 0; i < hashTable.length; i++) { //start of for loop
            if(hashTable[i] != null && hashTable[i].getKey() != -111){ //checking if hashtable at point i is available or null

                int storageIndex = hashTable[i].getKey() % newCapacity; //hash with new size
                if(storageIndex < 0) { //checking if storage index is negative
                    storageIndex = storageIndex + newCapacity; //creating the storage class
                } //end of if statement

                if (workingHashTable[storageIndex] == null || workingHashTable[storageIndex].getKey().equals(-111) ) { //check if hashtable is empty or available
                    workingHashTable[storageIndex] = new ValueEntry(hashTable[i].getKey()); //no collision
                } else { //linear probing if full
                    int newIndex = (storageIndex + 1) % newCapacity; // +i checks element to the right
                    while (workingHashTable[newIndex] != null && workingHashTable[newIndex].getKey() != -111) { //while the hashtable is null or available
                        newIndex = (newIndex + 1) % newCapacity; //checking the newIndex
                    } //end of while loop
                    workingHashTable[newIndex] = new ValueEntry(hashTable[i].getKey()); //setting the value in workingHashTable to the key of the object
                } //end of else statement

            } //end of large if statement
        }//end of for loop

        hashTable = workingHashTable; //update base variables
        tableCapacity = newCapacity; //setting the capacity to the newCapacity
    }//end of method reHashingWithLinearProbe

    public static void removeValueLinearProbe(Integer key) { //start of removeValueLinearProbe method
        int Element = key % tableCapacity;//where the value should be if there is no collision
        if(Element < 0) { //checking if the StorageElement is negative
            Element = Element + tableCapacity; //adding tableCapacity to storageElement
        }//end of if statement
        boolean keyFound = false; //initializing keyFound

        if (hashTable[Element] != null && hashTable[Element].getKey().equals(key)) { //if value is equal to the key and not null
            hashTable[Element].setKey(-111); //removes element and -111 for available
            keyFound = true; //setting keyFound to true
        }//end of if statement

        else { //linear probing if not equal to
            for (int i = 1; i < tableCapacity; i++) { //start of for loop
                int newIndex = (Element + i) % tableCapacity; //creating the newIndex
                if(hashTable[newIndex] != null && hashTable[newIndex].getKey().equals(key)) { //checks index to the right +1
                    hashTable[newIndex].setKey(-111); //setting key to available
                    keyFound = true; //setting keyFound to true
                }//end of if statement
            }//end of for loop
        }//end of else statement
        if(keyFound) {
            System.out.print(key + " is found and removed! ");//formatting
            printHashTable();//print hash table
        }
        else {
            System.out.print(key + " is not found! "); //formatting
            printHashTable(); //print the hash table
        }
    }//removeValueLinearProbe

    public static void printHashTable() {//start of method printHashTable
        System.out.print("The current Hash-Table: [");// printing out the current hash table

        for(int i = 0 ; i < tableCapacity ; i++) { //start of for loop
            if (hashTable[i] == null) //check for null spaces
                System.out.print("null"); //print out that space is null
            else if (hashTable[i].getKey() == -111) { //For available spaces
                System.out.print("available"); } //print out that space is available
            else {
                System.out.print(hashTable[i].getKey()); //for normal key value
            }
            if (i < tableCapacity - 1) {
                System.out.print(", "); //print comma and space at the end
            }
        }  System.out.print("]\n"); //printing out for formatting
    }//end of printHashTable method

    public static int checkPrime(int n) { //start of checkPrime method and return the nearest prime number
        int m = n / 2;//we just need to check half of the n factors
        for (int i = 3; i <= m; i++) {
            if (n % i == 0) {//if n is not a prime number
                i = 2; //reset i to 2 so that it is incremented to 3 in the forheader
                //System.out.printf("i = %d\n",i);
                n++;//next n value
                m = n / 2;//we just need to check half of the n factors
            }//end of if statement
        }//end of for loop
        return n;//return value of n
    }//end of checkPrime method

    public static void addValueLinearProbe(Integer key) { //start of addValueLinearProbe method

        int Index = key % tableCapacity; //determines where the key will be stored in the hashtable
        if(Index < 0) { //start of if statement if index is negative
            Index = Index + tableCapacity;
        }//end of if statement

        if (hashTable[Index] == null || hashTable[Index].getKey().equals(-111) ) { //check if is full to insert key
            hashTable[Index] = new ValueEntry(key); //inserting key
        } else { //linear probing if full
            for (int i = 1; i < tableCapacity; i++) { //start of for loop
                int newIndex = (Index + i) % tableCapacity; //adding i to move element to the right
                if (hashTable[newIndex] == null || hashTable[newIndex].getKey().equals(-111)) { //checking if table is null or available
                    hashTable[newIndex] = new ValueEntry(key);//setting value
                    break; //when found exit loop
                }//end of if statement
            } //end of for loop
        }//end of else statement
    } //end of method addValueLinearProbe

    public static void myHeader (String myInfo, int labE_number, int q_number){ //start of myHeader method
        System.out.println("======================================================="); //formatting
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number); //print out lab number and question number
        System.out.println("Prepared by: " + myInfo); //prepared by
        System.out.println("Goal of this Exercise: Using various hashing methods to resolve collisions in a data set");// goal, hard coded
        System.out.println("======================================================="); //formatting
    } //end of myHeader method

    public static void main(String[] args) { //start of main method
        myHeader("Shaheer Amir", 7, 1); //myHeader


        System.out.println("Let's decide on the initial table capacity based on the load factor and dataset size"); //prompt user for table capacity
        System.out.print("How many data items: "); //prompt user
        items = input.nextInt(); //user input
        System.out.print("What is the load factor (Recommended: <=0.5): "); //prompt user for load factor
        lf = input.nextDouble(); //user input
        int size = (int) (items/lf); //creating size equal to items over load factor
        tableCapacity = checkPrime(size); //calculate minimum table size using method
        System.out.print("The minimum required table capacity would be: " + tableCapacity + "\n"); //print out minimum capacity

        hashTable = new ValueEntry[tableCapacity]; //creating hash Table with tablecapacity size
        for (int i = 0; i < items; i++) { //start of for loop to add hash table contents
            System.out.print("Enter item " + (i+1) + ": ");
            int user = input.nextInt();//user input
            addValueLinearProbe(user); //adding using linearProbe
        }//end of for loop
        printHashTable();//print the hash table

        System.out.println("Let's remove two value from the table and then add one..."); //formatting
        System.out.print("Enter a value you want to remove: ");
        int remove = input.nextInt();//user input
        removeValueLinearProbe(remove); //call removeValueLinearProbe method

        System.out.print("Enter a value you want to remove: "); //prompting user to enter value
        int remove2 = input.nextInt();//user input
        removeValueLinearProbe(remove2);//call removeValueLinearProbe method

        System.out.print("Enter a value to add to the table: "); //prompt user to add value to table
        int add = input.nextInt(); //user input
        addValueLinearProbe(add);//add value using addValue method
        printHashTable();//print Hash Table

        System.out.println("Rehashing the table..."); //formatting
        int tempTableCapacity = (tableCapacity*2); //creating temporary table Capacity
        int newTableCapacity = checkPrime(tempTableCapacity);//new table capacity is next prime number
        System.out.println("The rehashed table capacity is: " + newTableCapacity); //formatting
        reHashingWithLinearProbe(); //printing out rehashed table
        printHashTable();//printing out hash Table

        myFooter("Shaheer", 7, 1); //call my footer method
    }

    public static void myFooter(String myInfo, int labE_number, int q_number){ //start of myFooter method
        System.out.println("\n======================================================="); //formatting
        System.out.println("Completion of Lab Exercise " + labE_number + "-Q" +q_number + " is successful!");//print out lab exercise and number
        System.out.println("Signing off - " + myInfo); //hard code
        System.out.println("======================================================="); //formatting
    } //end of myFooter method
}