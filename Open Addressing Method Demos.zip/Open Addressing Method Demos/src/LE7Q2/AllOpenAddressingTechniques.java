package LE7Q2; //package name

import LinearProbing.ValueEntry;//import classes
import static LinearProbing.HashingDemoWithLinearProbing.*; //import static values
import java.util.*;//import java.*

public class AllOpenAddressingTechniques { //start of class

    public static void emptyHashTable() {//start of empty hash table method
        for (int i = 0; i < hashTable.length; i++) {
            hashTable[i] = new ValueEntry(-1); //set each value to null
        }
    }//end of empty hash table method

    public static void addValueQuadraticProbe(Integer key) {//start of add value quadratic probing method
        int Index = key % tableCapacity; //setting storage index to key mod capacity
        if (Index < 0) { //checking if storage index is negative
            Index += tableCapacity; //adding value of table capacity back
        }

        int i = 1;//for iteration
        while (hashTable[Index] != null && !hashTable[Index].getKey().equals(-111)) { //checking if hashtable is null or available at points
            Index = (key % tableCapacity + i * i) % tableCapacity; // Ensuring index stays within bounds
            i++;//iterating i
        }//end of if statement

        hashTable[Index] = new ValueEntry(key);//setting hashtable at point equal to new object with key value
    }//end of addValueQuadraticProbe method

    public static void addValueDoubleHashing(Integer key) { //start of addValueDoubleHashing method
        int hash1 = (key % tableCapacity + tableCapacity) % tableCapacity; //setting hash1 bounds

        if(hashTable[hash1] == null){ //check if hash table at hash 1 is null
            hashTable[hash1] = new ValueEntry(key); //setting value of key to hashtable at hash1
        }
        else { //if it is not null
            int hash2 = thePrimeNumberForSecondHashFunction(tableCapacity - 1) - 1; //hash 2 is the second prime number in the capacity
            int i = 1; //iteration
            int storageIndex = ((hash1 + (i * hash2)) % tableCapacity); //creating the storage index

            while (hashTable[storageIndex] != null && hashTable[storageIndex].getKey() != -111) { //checking if hashtable is not null or available
                i++; //iteration
                storageIndex = (hash1 + (i * hash2)) % tableCapacity; //setting new storage index
            }//end of while loop
            hashTable[storageIndex] = new ValueEntry(key); //adding the value into the hash Table
        }//end of else statement
    }//end of doubleHashing method


    public static int thePrimeNumberForSecondHashFunction(int currentCapacity) {//method for checking if the number is Prime for DoubleHashing
            int m = currentCapacity;//we need to check half of the n factors
            for (int i = 3; i < currentCapacity; i++) {
                if (currentCapacity % i == 0) {//if n is not a prime number
                    i = 2; //reset i to 2 so that it is incremented to 3 in the for header
                    //System.out.printf("i = %d\n",i);
                    currentCapacity--;//decrement n value
                    m = currentCapacity / 2;//we just need to check half of the n factors
                }
            }
            return currentCapacity;//return prime number
        }//end of method

    public static void printArray(Integer [] values){ //start of printArray method
        System.out.println("The Given Data-Set: " + Arrays.asList(values)); //print Array as list
    }//end of printArray method

    public static void main(String[] args) { //start of main method
        myHeader("Shaheer Amir", 7, 2); //myHeader method

        // Initializing the hash table
        System.out.print("How many data items: "); //formatting
        items = input.nextInt(); //user input
        System.out.print("What is the load factor (Recommended: <= 0.5): "); //formatting
        lf = input.nextDouble(); //user input
        int size = (int) (items / lf); //creating size by dividing items over load factor
        tableCapacity = checkPrime(size);//making tablecapacity equal to next prime number
        System.out.println("The minimum required table capacity would be: " + tableCapacity); //formatting
        hashTable = new ValueEntry[tableCapacity];//creating hash table with size tableCapacity

        Integer [] array = new Integer[items]; //creating integer array
        for(int i = 0; i < items; i++){
            System.out.print("Enter item: " + (i+1) + ": "); //prompting user to enter values
            int user = input.nextInt(); //user input
            array[i] = user; //adding values to array
        }//end of for loop

        printArray(array);//printing out the contents

        System.out.println("\nAdding data - linear probing resolves collision"); //formatting
        for(int i = 0; i < items; i++){//for loop
            addValueLinearProbe(array[i]);//adding values using linear Probe method
        }
        printHashTable();//print hash table
        emptyHashTable();

        //reinitialize the hash table for Quadratic Probing
        System.out.println("\nAdding data - Quadratic probing resolves collision"); //formatting
            hashTable = new ValueEntry[tableCapacity]; //setting hash table to new shaheerValueEntry and size tableCapacity
            for (int i = 0; i < items; i++) {
                addValueQuadraticProbe(array[i]); //adding values using addValueQuadraticProbe
            }


        printHashTable();//print hash table
        emptyHashTable();

        // Reinitialize the hash table for Double Hashing
        hashTable = new ValueEntry[tableCapacity];
        System.out.println("\nAdding data - double-hashing resolves collision");//formatting
        for(int i = 0; i < items; i++){
            addValueDoubleHashing(array[i]);//add values using DoubleHashing
        }
        System.out.println("The q value is: " + thePrimeNumberForSecondHashFunction(tableCapacity - 1)); //printing the q value
        printHashTable();//printing the hash table

        myFooter("Shaheer", 7, 2);//call my footer method
    }//end of driver class
}//end of main class